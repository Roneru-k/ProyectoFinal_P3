<?php
$dsn = 'mysql:host=localhost;dbname=if0_37767491_libreria_db;charset=utf8';
$username = 'root';
$password = '';

try {

    $pdo = new PDO($dsn, $username, $password);

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error al conectar con la base de datos: " . $e->getMessage());
}
?>
